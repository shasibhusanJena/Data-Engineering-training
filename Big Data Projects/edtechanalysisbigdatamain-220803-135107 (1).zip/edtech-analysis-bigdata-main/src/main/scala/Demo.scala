object Demo extends App {
  println("hello world!!")
}
