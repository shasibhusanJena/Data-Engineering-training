package com.edtech.processing

object ProcessingConstants {
  val SPARK_APPLICATION_NAME = "EDTECH_ANALYSIS_PROCESSING"
}
